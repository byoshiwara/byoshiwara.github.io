function trmnator(action)
% callbacks for the Terminator game (terminator.m)
% Original author: Bob Martinez, Los Angeles Pierce College (Mathcad)
% Translated to MATLAB by Bruce Yoshiwara, LA Pierce College  
%
% To start the game, type   terminator    at the MATLAB prompt.
% This M-file, terminator.mat, and terminator.m must be on your path.

global Fs;global y;			% variables for audio

switch(action)

case 'init'		% Initiates the game "Terminate the Terminator"
 h2 = findobj( gcf, 'Tag', 'lock' );
 h3 = findobj( gcf, 'Tag', 'back' );
 set(h2,'Visible','off'); %turn off lock
 set(h3,'Visible','off'); %turn off lock
 axis([-5 5 -5 5]); axis square; cla; grid off;
 drawax;
 set(gca,'xtick',[-5:5]);
 set(gca,'ytick',[-5:5]);
 Base;
 drawcirc;
 P=NewTrmtr;

case 'reset'		% Resets the game "Terminate the Terminator"
 cla;
 axis([-5 5 -5 5]); axis square; cla; grid off;
 h2 = findobj( gcf, 'Tag', 'lock' );
 h3 = findobj( gcf, 'Tag', 'back' );
 set(h2,'Visible','off'); %turn off lock
 set(h3,'Visible','off'); %turn off lock
 drawax;
 Base;
 drawcirc;
 P=NewTrmtr;

case 'range'		% This is the callback for the range edit box 
 r = GetRange;
 recirc;

case 'angle'		% This is the callback for the angle edit box 
 h1=findobj(gca,'Tag','xaxis');
 P = get(h1,'ZData');
 h2 = findobj( gcf, 'Tag', 'lock' );
 h3 = findobj( gcf, 'Tag', 'back' );
 set(h2,'Visible','off'); %turn off lock
 set(h3,'Visible','off'); %turn off lock
 theta = GetTheta;
 Pointer(theta)
 if abs(atan2(P(2),P(1))-atan2(sin(theta),cos(theta))) <.05
	set(h2,'Visible','on'); %turn on lock
 elseif abs(atan2(P(2),P(1))-atan2(sin(theta-pi),cos(theta-pi))) <.05
	set(h3,'Visible','on'); %turn on lock
 end

case 'fire'					% Firing the weapon
 h=findobj('Tag','audio');
 AudioFlag=get(h,'Value');
 ray = findobj(gca,'Tag','ray');
 theta = GetTheta;
 r = GetRange;
 set(ray,'XData', [0;r*cos(theta)],...
   'YData', [0;r*sin(theta)]);			% draw new beam
 h1=findobj(gca,'Tag','xaxis');
 P = get(h1,'ZData');
 if norm(P-[r*cos(theta) r*sin(theta)]) < .3
    Term = findobj(gca,'Tag','Term');
    base = findobj(gca,'Tag','base');
    circ = findobj(gca,'Tag','circle');
    G = get(base,'UserData');
    set(Term,'XData', [0], ...
    'YData', [0]);				% terminator off screen
    set(circ,'XData', [0], ...
    'YData', [0]);				% circle off screen
     explode(P)					% draw explosion on screen
    if AudioFlag
	sound(y,Fs);
    end
 end;

case 'grid'
 h=findobj(gcf,'Tag','grid');
 cmd = get(h,'String');
 if isempty(findstr(cmd,'off')); 		% turn on grid
  grid on;
  set(h,'String','grid off');
 else						% turn grid off
  grid off;
  set(h,'String','grid on');
 end

case 'show'					% revealing options
   if strcmp(get(gcbo,'Checked'),'off')
      set(gcbo,'Checked','on');
      h=findobj(gcf,'Tag','grid');
      set(h,'Visible','on');
      h=findobj(gcf,'Tag','audio');
      set(h,'Visible','on');
   else
      trmnator hide-ops;
   end
   
case 'hide-ops'					% hiding options
   h=findobj(gcf,'Tag','grid');
   set(h,'Visible','off');
   h=findobj(gcf,'Tag','audio');
   set(h,'Visible','off');
   set(findobj('Tag','show-ops'),'Checked','off');
   
case 'start'					% hiding opening credits
 h=findobj(gcf,'Tag','angle');
 set(h,'Visible','on');
 h=findobj(gcf,'Tag','range');
 set(h,'Visible','on');
 h=findobj(gcf,'Tag','fire');
 set(h,'Visible','on');
 h=findobj(gcf,'Tag','quit');
 set(h,'Visible','on');
 h=findobj(gcf,'Tag','reset');
 set(h,'Visible','on');
 h=findobj(gcf,'Tag','rangetitle');
 set(h,'Visible','on');
 h=findobj(gcf,'Tag','angletitle');
 set(h,'Visible','on');

 h=findobj(gcf,'Tag','credits');
 set(h,'Visible','off');
 h=findobj(gcf,'Tag','bob');
 set(h,'Visible','off');
 h=findobj(gcf,'Tag','me');
 set(h,'Visible','off');
 h=findobj(gcf,'Tag','school');
 set(h,'Visible','off');
 h=findobj(gcf,'Tag','title');
 set(h,'Visible','off');
 h=findobj(gcf,'Tag','click');
 set(h,'Visible','off');

case 'audio'					% audio option
 h=findobj('Tag','audio');
 AudioFlag=get(h,'Value');
 if AudioFlag
  load handel
 end

case 'hw'					% show assignment
   if strcmp(get(gcbo,'Checked'),'off')
      set(gcbo,'Checked','on');
 h=findobj(gcf,'Tag','HwBackground');
 set(h,'Visible','on');
 h=findobj(gcf,'Tag','line1');
 set(h,'Visible','on');
   else
      trmnator hide-hw;
   end


case 'hide-hw'					% hiding the assignment
 h=findobj(gcf,'Tag','HwBackground');
 set(h,'Visible','off');
 h=findobj(gcf,'Tag','line1');
 set(h,'Visible','off');
      set(findobj('Tag','show-hw'),'Checked','off')


end

function P=NewTrmtr				% relocate the Terminator
 rand('state',sum(100*clock))
 P = 4*rand(1,2)+1;
 Q = 2*(rand(1,2)<0.5)-1;
 P=P.*Q;
 h1=findobj(gca,'Tag','base');
 XYData=get(h1,'UserData');
 gx=XYData(:,1)'; gy=XYData(:,2)';
 t=get(h1,'ZData');
 plot(gx+P(1),gy+P(2),...
      'EraseMode','xor',...
      'Tag','Term',...
      'color',[1 .5 .5],'LineWidth',3.5);		%terminator
 h1=findobj(gca,'Tag','xaxis');
 set(h1,'ZData',P);

function Base	% draw the weapon
 t = 0:0.05:2*pi;
 gx = 0.2*cos(t);
 gy = 0.2*sin(t);
 base=line(gx,gy,'Color','b','LineWidth',3.5,'Tag','base');	%weapon
 set(base,'UserData',[gx' gy']);
 set(base,'ZData',t);	% this is a stupid place to store data

 Hit=exp((sin(15*t+2).^2+cos(12*t)))*.5;		%explosion
 ex0=Hit.*cos(t);ey0=Hit.*sin(t);
 expl = line(ex0+100,ey0+100,...
      'EraseMode', 'xor',...
      'Tag','expl',...
      'color','r','LineStyle','--');
 set(expl,'UserData',[ex0' ey0']);		% store data for explosion
 theta = GetTheta;
 G = [0 0; .7*cos(theta) .7*sin(theta);...
     .3*cos(theta+pi/2) .3*sin(theta+pi/2);...
     .3*cos(theta-pi/2) .3*sin(theta-pi/2);...
     .7 * cos(theta) .7*sin(theta)];
 plot(G(:,1),G(:,2),...
      'EraseMode', 'xor',...
      'Tag','point',...
      'color','k');	%firing pointer
 line([0;0],[0;0],...
      'EraseMode', 'xor',...
      'Tag','ray',...
      'color','g','LineStyle','-.');		%firing line-of-sight


function theta=GetTheta				% read angle from edit box
 h1 = findobj(gcf, 'Tag', 'angle' );
 str = get(h1, 'String');
 eval( ['theta = [' str '];' ] ) 		% assign new theta
 set( h1, 'String', theta );


function Pointer(theta)				% draw weapon pointer
 G = [0 0; .7*cos(theta) .7*sin(theta);...
     .3*cos(theta+pi/2) .3*sin(theta+pi/2);...
     .3*cos(theta-pi/2) .3*sin(theta-pi/2);...
     .7 * cos(theta) .7*sin(theta)];
 point = findobj(gca,'Tag','point');
 set(point,'XData', G(:,1),...
   'YData', G(:,2));				% draw pointer
 ray = findobj(gca,'Tag','ray');
 set(ray,'XData', [0;0],...
   'YData', [0;0]);				% remove ray

function explode(P)				% draw explosion
 expl = findobj(gca,'Tag','expl');
 explod = get(expl,'UserData');
 set(expl,'XData', explod(:,1)+P(1),...
       'YData', explod(:,2)+P(2),...
       'color',[1 .5 .5]);	

function r=GetRange
 h1 = findobj(gcf, 'Tag', 'range' );
 str = get(h1, 'String');
 eval(['r = [' str '];' ] )            		% extra []'s don't hurt
 set(h1, 'String', r )

function drawax					% draw axes
 plot([-5;5],[0;0],'c','Tag','xaxis');plot([0;0],[-5;5],'c'); %axes

function drawcirc				% draw circle for range
 r = GetRange;
 t = 0:0.05:2*pi;
 line(r*cos(t),r*sin(t),...
      'EraseMode','xor',...
      'Tag','circle',...
      'color','m',...
      'LineStyle',':');				% circle of range

function recirc					% redraw circle for range
 r = GetRange;
 h2=findobj(gca,'Tag','circle');
 t = 0:0.05:2*pi;
 set(h2,'XData',r*cos(t),...
      'YData',r*sin(t));			% circle of range
